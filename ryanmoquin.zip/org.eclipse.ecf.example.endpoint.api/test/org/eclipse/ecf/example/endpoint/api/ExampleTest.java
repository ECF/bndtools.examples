package org.eclipse.ecf.example.endpoint.api;

import static org.junit.Assert.*;

import org.junit.Test;

public class ExampleTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
